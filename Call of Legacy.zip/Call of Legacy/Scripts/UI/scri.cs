﻿using UnityEngine;
using System.Collections;

public class scri : MonoBehaviour {
    public GameObject go;
	// Use this for initialization
	void Start () {
	
	}
	
    public void SCRIPT()
    {
        go.SetActive(false);
    }
	// Update is called once per frame
	void Update () {
	
	}
}
